package com.example.weathermod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class WeatherStructureMod implements ModInitializer {

    public static final String MOD_ID = "weatherstructuremod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private enum WeatherType { CLEAR, RAIN, THUNDER }

    // Cache values() array — avoids a new allocation on every weather change
    private static final WeatherType[] WEATHER_TYPES = WeatherType.values();

    private final Map<String, Integer> weatherTimers = new HashMap<>();

    // 5–15 minutes in ticks (20 ticks/sec × 60 sec/min)
    private static final int MIN_TICKS = 5  * 60 * 20;  // 6,000
    private static final int MAX_TICKS = 15 * 60 * 20;  // 18,000

    @Override
    public void onInitialize() {
        LOGGER.info("[WeatherStructureMod] v1.1.0 — Fabric — Dynamic Weather & Structure Boost active.");
        ServerTickEvents.END_WORLD_TICK.register(this::onWorldTick);
    }

    private void onWorldTick(class_3218 world) {
        if (!world.method_27983().equals(class_1937.field_25179)) return;

        String key = world.method_27983().method_29177().toString();

        // First tick for this world: initialise the countdown and return
        if (!weatherTimers.containsKey(key)) {
            int initial = randomInterval();
            weatherTimers.put(key, initial);
            LOGGER.info("[WeatherStructureMod] First weather change in {} ticks (~{} sec).", initial, initial / 20);
            return;
        }

        int ticksLeft = weatherTimers.get(key) - 1;
        if (ticksLeft <= 0) {
            applyRandomWeather(world);
            int next = randomInterval();
            weatherTimers.put(key, next);
            LOGGER.info("[WeatherStructureMod] Next weather change in {} ticks (~{} sec).", next, next / 20);
        } else {
            weatherTimers.put(key, ticksLeft);
        }
    }

    private void applyRandomWeather(class_3218 world) {
        // ThreadLocalRandom — faster than shared Random, no lock contention
        WeatherType chosen = WEATHER_TYPES[ThreadLocalRandom.current().nextInt(WEATHER_TYPES.length)];
        switch (chosen) {
            case CLEAR   -> { world.method_27910(6000, 0,    false, false); LOGGER.info("[WeatherStructureMod] Weather → CLEAR."); }
            case RAIN    -> { world.method_27910(0,    6000, true,  false); LOGGER.info("[WeatherStructureMod] Weather → RAIN."); }
            case THUNDER -> { world.method_27910(0,    6000, true,  true);  LOGGER.info("[WeatherStructureMod] Weather → THUNDER."); }
        }
    }

    private static int randomInterval() {
        return MIN_TICKS + ThreadLocalRandom.current().nextInt(MAX_TICKS - MIN_TICKS + 1);
    }
}
